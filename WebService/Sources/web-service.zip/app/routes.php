<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

// Info :
Route::any('/', 'InfoController@start');

// User :
Route::post('/user/register', 'UserController@register');                       // Enregistrement de l'utilisateur sur l'application (genere clé et envoie mail)
Route::post('/user/connect', 'UserController@connect');                         // Connexion de l'utilisateur la premiere fois
Route::post('/user/disconnect', 'UserController@disconnect');                   // Déconnexion de l'utilisateur la premiere fois

// Station :
Route::post('/station/push', 'StationController@push');                         // Enregistrement et mise à jour des informations de la station (ip, date, ... + mails si décalage de connexion régulière)
Route::post('/station/alert', 'StationController@alert');                        // Envoie d'une alerte quand la station est trop longtemps deconnecter.    

// Request :
Route::post('/request/app/push', 'RequestController@app_push');                 // Soumission de la demande SQL de la part de l'application.
Route::post('/request/app/pull', 'RequestController@app_pull');             // Récupération de la réponse donner par la station meteo de la part de l'application.
Route::post('/request/raspberry/push', 'RequestController@raspberry_push');// Soumission de la demande SQL de la part de la raspberry pi.
Route::post('/request/raspberry/pull', 'RequestController@raspberry_pull');     // Récupération de la réponse donner par la station meteo de la part de la raspberry pi.
