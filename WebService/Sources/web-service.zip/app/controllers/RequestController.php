<?php

class RequestController extends BaseController {
    
    // Route /Request/app/push
    public function app_push() {
        // Déclaration :
            $result = array('code' => 0);
        
        // Traitement :
            Input::replace(array("request"=>stripslashes(trim(Input::get("request")))));
            $requete = Input::get("request");
            
            if(!Auth::check()){ $result=array("code"=>0, "status"=>"Vous n'êtes pas connecter."); }
            else if(!empty($requete)){
                $request = new Requete();
                $request->station_id = Auth::user()->id;
                $request->user_id = Auth::user()->id;
                $request->request_id = rand(1200, 3000);
                $request->request = Input::get("request");
                $request->date = date("Y-m-d H:i:s");
                try{ $request->save(); $result=array("code"=>1, 
                                                     "status"=>"La requete vas être traité.", 
                                                     "data" =>array("request_id"=>$request->request_id)
                                                    ); }
                catch(Exception $e){ $result=array("code"=>0, "status"=>"La requete à été rejeté."); }
            }
        
        // Retour :
            $response = array(
                "request"=>Request::path(),
                "arguments"=> Input::all(),
                "response"=>$result,
                "code"=>200
            );    
        
        return Response::json($response)->setCallback(Input::get('callback'));
    }
    
    // Route /Request/app/pull
    public function app_pull() {
        // Déclaration :
            $result = array('code' => 0);
        
        // Traitement :
            Input::replace(array("id"=>stripslashes(trim(Input::get("id")))));
            $id = Input::get("id");
        
            if(!Auth::check()){ $result=array("code"=>0, "status"=>"Vous n'êtes pas connecter."); }
            elseif(!empty($id) && $id>0){
                $request = Requete::whereRaw("station_id=? AND user_id=? AND request_id =?", array( Auth::user()->id, 
                                                                                                    Auth::user()->id, 
                                                                                                    $id));
                
                if($request->count() == 1){
                    $request = $request->first();
                    
                    if(!empty($request->response)){ $result=array("code"=>1, "status"=>"La requete à été traiter.", "data"=>$request); }
                    else{ $result=array("code"=>0, "status"=>"La requete n'as pas encore été traiter."); }
                }
                else{ $result=array("code"=>0, "status"=>"Il n'y a pas de requete associé à cette ID."); }
            }
        
        
        // Retour :
            $response = array(
                "request"=>Request::path(),
                "arguments"=> array("request"=>$id),
                "response"=>$result,
                "code"=>200
            );    
        
        return Response::json($response)->setCallback(Input::get('callback'));
    }

    // Route /Request/raspberry/pull
    public function raspberry_pull() {
        // Déclaration :
            $result = array('code' => 0);
        
        // Traitement :
            Input::replace(array("email"=>stripslashes(trim(Input::get("email"))),
                                 "privatekey"=>stripslashes(trim(Input::get("privatekey"))) ));
        
            $validator = Validator::make(Input::get(),array(
                'email' => 'required|email',
                'privatekey' => 'required'
            ));
            
            /* si argument pas valide on arrete tout  */
            if($validator->fails()){ $result=array("code"=>0, "status"=>"Les informations de la stations sont érronées."); }
            
            /* sinon */
            else {
                $user = User::WhereRaw("email=? AND privatekey=?", array(Input::get("email"), Input::get("privatekey")));
                
                if($user->count() == 1){ 
                    $request = Requete::whereRaw("station_id=? AND user_id=? AND response IS NULL", array($user->first()->id, $user->first()->id))->get();
                    $result=array("code"=>1, "status"=>"Des requetes sont à traiter.", "data"=>$request); }
                else{
                    $result=array("code"=>0, "status"=>"Il n'y as pas de requete à traiter.");
                }
            }
        
        
        // Retour :
            $response = array(
                "request"=>Request::path(),
                "arguments"=> Input::all(),
                "response"=>$result,
                "code"=>200
            );    
        
        return Response::json($response)->setCallback(Input::get('callback'));
    }

    // Route /Request/raspberry/push
    public function raspberry_push() {
        // Déclaration :
            $result = array('code' => 0);
        
        // Traitement :
            Input::replace(array("email"=>stripslashes(trim(Input::get("email"))),
                                 "privatekey"=>stripslashes(trim(Input::get("privatekey"))),
                                 "id"=>stripslashes(trim(Input::get("id"))),
                                 "response"=>stripslashes(trim(Input::get("response"))) ));
        
            $validator = Validator::make(Input::get(),array(
                'email' => 'required|email',
                'privatekey' => 'required',
                'id' => 'required'
            ));
            
            
            /* si argument pas valide on arrete tout  */
            if($validator->fails()){ $result=array("code"=>0, "status"=>"Les informations de la stations sont érronées."); }
            
            /* sinon */
            else {
                /* on verifie les accès de l'utilisateur */
                $user = User::WhereRaw("email=? AND privatekey=?", array(Input::get("email"), Input::get("privatekey")));
                if($user->count() == 1){
                    
                    $requete = Requete::whereRaw("station_id=? AND user_id=? AND request_id=?", array(  $user->first()->id, 
                                                                                                        $user->first()->id, 
                                                                                                        Input::get("id"))   );
                    if($requete->count() == 1){
                        $requete = $requete->first();
                        $requete->response = Input::get("response");
                        
                        try{ $requete->save(); $result=array("code"=>1, "status"=>"La réponse à la requete à été enregistrer."); }
                        catch(Exception $e){ $result=array("code"=>0, "status"=>"La réponse à la requete n'a pas été enregistrer."); }
                    }
                    else{ $result=array("code"=>0, "status"=>"La requete n'a pas été trouvé."); }
                    
                }
                else{
                    $result=array("code"=>0, "status"=>"La réponse de la requete n'est pas autoriser.");
                }
            }
        
        // Retour :
            $response = array(
                "request"=>Request::path(),
                "arguments"=> Input::all(),
                "response"=>$result,
                "code"=>200
            );    
        
        return Response::json($response)->setCallback(Input::get('callback'));
    }    
}
