<?php

class UserController extends BaseController {
    // METHODES :
    // get the ip of client :
    private function get_client_ip() {
        $ipaddress = '';
        if (getenv('HTTP_CLIENT_IP'))
            $ipaddress = getenv('HTTP_CLIENT_IP');
        else if(getenv('HTTP_X_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
        else if(getenv('HTTP_X_FORWARDED'))
            $ipaddress = getenv('HTTP_X_FORWARDED');
        else if(getenv('HTTP_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_FORWARDED_FOR');
        else if(getenv('HTTP_FORWARDED'))
           $ipaddress = getenv('HTTP_FORWARDED');
        else if(getenv('REMOTE_ADDR'))
            $ipaddress = getenv('REMOTE_ADDR');
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }
    
    // Route /User/register
    public function register() {
        // Declaration :
            $result = array('code' => 0);
        
        // Traitements :
            Input::replace(array("email"=>stripslashes(trim(Input::get("email"))),
                                 "password"=>stripslashes(trim(Input::get("password"))),
                                 "name"=> stripslashes(trim(Input::get("name"))) ));
            
            
            $validator = Validator::make(Input::get(),array(
                'name' => 'required',
                'email' => 'required|email',
                'password' => 'required|min:6'
            ));
            
            
            if(Auth::check()){ $result=array("code"=>0, "status"=>"Vous déjà connecter."); }
            elseif($validator->fails()){ $result=array("code"=>0, "status"=>"Les champs demander ne sont saisie correctement."); }
            elseif(User::where("email", "=", Input::get("email"))->count() == 0){
                $privateKey =md5(microtime().rand());
                
                $register = new User();
                $register->privatekey = $privateKey;
                $register->email = Input::get("email");
                $register->password = md5(Input::get("password"));
                $register->nom = Input::get("name");
                $register->dateInscription = date("Y-m-d H:i:s");
                $register->dateDerniereConnexion = date("Y-m-d H:i:s"); 
                $register->ipDerniereConnexion = $this->get_client_ip(); 
                
                try{ 
                    $register->save();
                    $result= array("code"=>1, "status"=>"Ajout de l'utilisateur OK.");
                    
                    /* Envoi du mail */
                    Mail::send('emails.register', array( "email" => Input::get("email"),
                                                        "password" => Input::get("password"),
                                                        "privatekey" => $privateKey), function($message) {
                        $message->to(Input::get("email"))->cc('dawin.weatherstation@gmail.com')->subject('Welcome!');
                    });
                }
                catch(Exception $e){ $result= array("code"=>0, "status"=>"L'utilisateur n'as pas pu être ajouter."); }
            }else{
                 $result= array("code"=>0, "status"=>"L'utilisateur existe déjà."); 
            }
        
        // Retour :
            $response = array(
                "request"=>Request::path(),
                "arguments"=> Input::except('password'),
                "response"=>$result,
                "code"=>200
            );    
            
        return Response::json($response)->setCallback(Input::get('callback'));
    }
    
    // Route /User/connect
    public function connect() {
        // Declaration :
            $result = array('code' => 0);
        
        // Traitements :
            if(Auth::check()){ Auth::logout(); }
            Input::replace(array("email"=>stripslashes(trim(Input::get("email"))),
                                 "password"=>stripslashes(trim(Input::get("password"))) ));
            
            $validator = Validator::make(Input::get(),array(
                'email' => 'required|email',
                'password' => 'required|min:6'
            ));
            
            $user = User::whereRaw("email=? AND password=?", array(Input::get("email"), md5(Input::get("password"))));
            
            if($validator->fails()){ $result=array("code"=>0, "status"=>"Les champs demander ne sont saisie correctement."); }
            elseif($user->count() == 1){
                // récupération de l'utilisateur :
                $user = $user->first();
                $user_id = $user->id;
                
                // connexion :
                Auth::login($user);
                
                // mise à jour des paramètres de derniere connexion :
                $user->dateDerniereConnexion = date("Y-m-d H:i:s"); 
                $user->ipDerniereConnexion = $this->get_client_ip(); 
                $user->save();
                
                // ajout des station :
                $user_data = $user->toArray();
                $user_data["station"] = Station::whereRaw("user_id=?", array($user_id))->first();
                
                // result :
                $result=array("code"=>1, "status"=>"Conecté", "data"=>$user_data);
            }
            else{ $result=array("code"=>0, "status"=>"L'identifiant utilisateur ou le mot de passe est incorrecte."); }
        
        // Retour :
            $response = array(
                "request"=>Request::path(),
                "arguments"=> Input::except('password'),
                "response"=>$result,
                "code"=>200
            );    
        
        return Response::json($response)->setCallback(Input::get('callback'));
    }
    
    // Route /User/disconnect
    public function disconnect() {
        // Declaration :
            $result = array('code' => 0);
        
        // Traitements :
            if(Auth::check()){
                Auth::logout(); 
                $result = array('code' => 1, 'status'=>"Vous êtes déconnecter");
            }
            else{
                $result = array('code' => 1, 'status'=>"Vous êtiez déjà déconnecter");
            }
        
        // Retour :
            $response = array(
                "request"=>Request::path(),
                "arguments"=> Input::all(),
                "response"=>$result,
                "code"=>200
            );    
        
        return Response::json($response)->setCallback(Input::get('callback'));
    }
    
}
