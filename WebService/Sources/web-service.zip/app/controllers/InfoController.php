<?php

class InfoController extends BaseController {
    
    // Route /
	public function start()	{
	    $response = array(
            "request"=>Request::path(),
            "arguments"=> false,
            "response"=>1,
            "code"=>200
        );    
        
		return Response::json($response)->setCallback(Input::get('callback'));
	}
    
}
