<?php

class StationController extends BaseController {
    // METHODES :
    // get the ip of client :
    private function get_client_ip() {
        $ipaddress = '';
        if (getenv('HTTP_CLIENT_IP'))
            $ipaddress = getenv('HTTP_CLIENT_IP');
        else if(getenv('HTTP_X_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
        else if(getenv('HTTP_X_FORWARDED'))
            $ipaddress = getenv('HTTP_X_FORWARDED');
        else if(getenv('HTTP_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_FORWARDED_FOR');
        else if(getenv('HTTP_FORWARDED'))
           $ipaddress = getenv('HTTP_FORWARDED');
        else if(getenv('REMOTE_ADDR'))
            $ipaddress = getenv('REMOTE_ADDR');
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }
    
    // Route /Station/update
    private function register($arguments){
        $station = new Station();
        $station->user_id = User::WhereRaw("email=? AND privatekey=?", array($arguments["email"], $arguments["privatekey"]))->first()->id;
        $station->nom = $arguments['nom'];
        $station->lieu = $arguments['lieu']; 
        $station->altitude = $arguments['altitude'];
        $station->date_installation = date("Y-m-d H:i:s"); 
        $station->date_dernierPull = date("Y-m-d H:i:s"); 
        $station->ip = $this->get_client_ip();
        
        try{ $station->save(); $result=array("code"=>1, "status"=>"Station ajouter."); }
        catch(Exception $e){ $result=array("code"=>0, "status"=>"Erreur d'enregistrement de la station."); }
        
        return $result;
    }
    private function update($arguments){
        // A REGLER
        /* récupération de la station */
        $station = Station::whereRaw("USER_id=?", array(
            User::WhereRaw("email=? AND privatekey=?", array($arguments["email"], $arguments["privatekey"]))->first()->id
        ))->first();
        $station->nom = $arguments['nom'];
        $station->lieu = $arguments['lieu'];
        $station->altitude = $arguments['altitude'];
        $station->date_dernierPull = date("Y-m-d H:i:s"); 
        $station->ip = $this->get_client_ip();
        
        try{ $station->save(); $result=array("code"=>1, "status"=>"Mise à jour de la station."); }
        catch(Exception $e){ $result=array("code"=>0, "status"=>"Erreur de mise à jour de la station."); }
        
        return $result;
    }
    public function push() {
        // Declaration :
            $result = array('code' => 0);
        
        // Traitements :
            Input::replace(array("email"=>stripslashes(trim(Input::get("email"))),
                                 "privatekey"=>stripslashes(trim(Input::get("privatekey"))),
                                 "nom"=>stripslashes(trim(Input::get("nom"))),
                                 "lieu"=>stripslashes(trim(Input::get("lieu"))),
                                 "altitude"=>stripslashes(trim(Input::get("altitude"))) ));
        
            $validator = Validator::make(Input::get(),array(
                'email' => 'required|email',
                'privatekey' => 'required',
                'nom' => 'required',
                'lieu' => 'required',
                'altitude' => 'required'
            ));
            
            /* si argument pas valide on arrete tout  */
            if($validator->fails()){ $result=array("code"=>0, "status"=>"Les informations de la stations sont érronées."); }
            
            /* sinon */
            else {
                $user = User::WhereRaw("email=? AND privatekey=?", array(Input::get("email"), Input::get("privatekey")));
                /* si les paramètres de la station sont correctes */
                if($user->count() == 1){
                    /* on regarde s'il y as une station pour les arguments passé */
                    $station = Station::whereRaw("user_id=?", array($user->first()->id));
                    if($station->count() == 0){ $result = $this->register(Input::all()); }
                    else { $result = $this->update(Input::all()); }
                }
                else{
                    $result=array("code"=>0, "status"=>"L'adresse e-mail ou la clé privé sont érronées.");
                }
            }
        
        
        // Retour
            $response = array(
                "request"=>Request::path(),
                "arguments"=> Input::all(),
                "response"=>$result,
                "code"=>200
            );    
        
        return Response::json($response)->setCallback(Input::get('callback'));
    }
    
    public function alert(){
        // Declaration :
            $result = array('code' => 0);
        
        // Traitements :
            Input::replace(array("email"=>stripslashes(trim(Input::get("email"))),
                                 "privatekey"=>stripslashes(trim(Input::get("privatekey"))),
                                 "alert"=>stripslashes(trim(Input::get("alert"))) ));
        
            $validator = Validator::make(Input::get(),array(
                'email' => 'required|email',
                'privatekey' => 'required',
                'alert' => 'required'
            ));
            
            
            /* si argument pas valide on arrete tout  */
            if($validator->fails()){ $result=array("code"=>0, "status"=>"Les informations de la stations sont érronées."); }
            
            /* sinon */
            else {
                // on verifie que l'utilisateur existe :
                $user = User::WhereRaw("email=? AND privatekey=?", array(Input::get("email"), Input::get("privatekey")));
                
                if($user->count() == 1){
                    /* Envoi du mail */
                    Mail::send('emails.alert', array( "alert" => Input::get("alert")), function($message) {
                        $message->to(Input::get("email"))->subject('DaWeather - Alert');
                    });
                    $result=array("code"=>1, "status"=>"Alerte transmise.");
                }
                else{ $result=array("code"=>0, "status"=>"L'adresse e-mail ou la clé privé sont érronées."); }
            }            
            
        // Retour
            $response = array(
                "request"=>Request::path(),
                "arguments"=> Input::all(),
                "response"=>$result,
                "code"=>200
            );    
        
        return Response::json($response)->setCallback(Input::get('callback'));
    }
}
