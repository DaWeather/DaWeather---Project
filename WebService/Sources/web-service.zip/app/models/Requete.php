<?php

use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

class Requete extends Eloquent implements RemindableInterface {

    use RemindableTrait;
    
    // Paramètres : 
    protected $table = 'REQUEST';
    protected $primaryKey = 'id';
    public $timestamps = false;
    
    // Relations :
    public function station(){ return $this->belongsTo('Station', 'station_id'); }
    public function user(){ return $this->belongsTo('User', 'user_id'); }
}
