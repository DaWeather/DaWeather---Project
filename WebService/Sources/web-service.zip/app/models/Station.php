<?php

use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

class Station extends Eloquent implements RemindableInterface {
    use RemindableTrait;
    
    // Paramètres : 
    protected $table = 'STATION';
    protected $primaryKey = 'user_id';
    public $timestamps = false;
    
    // Relations :
    public function requests(){ return $this->hasMany('Request', "user_id"); }
    public function user(){ return $this->belongsTo('User', 'user_id'); }
}
