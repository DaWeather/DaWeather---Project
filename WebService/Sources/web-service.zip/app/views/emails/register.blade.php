<center>
    <h1>DaWeather</h1>
    
    <p><i class="fa fa-user"></i> Login : <span>{{ $email }}</span></p>
    <p><i class="fa fa-asterisk"></i> Password : <span>{{ $password }}</span></p>
    <p><i class="fa fa-key"></i> Private key :  <span>{{ $privatekey }}</span></p>
</center>