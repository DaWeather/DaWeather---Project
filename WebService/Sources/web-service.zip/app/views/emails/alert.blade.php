<center>
    <h1>DaWeather</h1>
    
    <p>{{ $alert }}</p>
</center>