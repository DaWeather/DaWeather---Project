@if(json)
    {{ json_encode(array(1,2,3)); }}
@endif
