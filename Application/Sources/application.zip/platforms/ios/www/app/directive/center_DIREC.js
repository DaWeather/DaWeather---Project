/*https://github.com/iameugenejo/angular-centered/angular-centered.js*/
angular.module("angular-center", []).directive("centerblock", function() {
  return {
		restrict : "ECA",
		transclude : true,
		template : "\
		<table valign=\"middle\" align=\"center\" border=\"0\" height=\"100%\" width=\"100%\"><tbody><tr height=\"100%\"><td align=\"center\" height=\"100%\" valign=\"middle\" width=\"100%\" \
			ng-transclude>\
		</td></tr></tbody></table>"
	};
});