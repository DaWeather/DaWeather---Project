// Normal traduction with HTML balise remplaced in compilation :
angular.module("angular-traduction", []).directive("traduction", ['language', function(language) {
	return {
		restrict : "ECA",
		transclude : true,
		template: function(elem, attr){
			var retour;
			
			if(typeof attr.filter == "undefined"){ attr.filter = null; }
			retour = language.recupere(attr.find, attr.filter);
			
			return retour;
		}
	};
}]);

// Specific traduction in placeholder input in compilation :
app.directive("ngTraductionPlaceholder", function($log, $timeout, language) {
    return {
        restrict: "A",
        link: function(scope, elem, attrs) {
            var txt = language.recupere(attrs.ngTraductionPlaceholder, null),
                model = attrs.ngModel,
                placeholderSupport = 'placeholder' in document.createElement("input");

            //Use HTML5 placeholder attribute.
            if (placeholderSupport) {
                attrs.$set("placeholder", txt);
                return;
            }

            elem.on("focus", function(event) {
                if (elem.val() === txt) {
                    elem.val("");
                }
            });

            elem.on("blur", function(event) {
                if (elem.val() === "") {
                    elem.val(txt);
                }
            });

            scope.$watch(model, function (newValue, oldValue, scope) {
                if (newValue === undefined || newValue === "") {
                    elem.val(txt);
                    //scope.$apply(); not needed, since scope fired this event.
                }
            }, true);
        }
    };
});

// Specific traduction in value input in compilation :
app.directive("ngTraductionValue", function($log, $timeout, language) {
    return {
        restrict: "A",
        link: function(scope, elem, attrs) {
            var txt = language.recupere(attrs.ngTraductionValue, null),
                model = attrs.ngModel,
                valueSupport = 'value' in document.createElement("input");

            //Use HTML5 value attribute.
            if (valueSupport) {
                attrs.$set("value", txt);
                return;
            }

            elem.on("focus", function(event) {
                if (elem.val() === txt) {
                    elem.val("");
                }
            });

            elem.on("blur", function(event) {
                if (elem.val() === "") {
                    elem.val(txt);
                }
            });

            scope.$watch(model, function (newValue, oldValue, scope) {
                if (newValue === undefined || newValue === "") {
                    elem.val(txt);
                    //scope.$apply(); not needed, since scope fired this event.
                }
            }, true);
        }
    };
});