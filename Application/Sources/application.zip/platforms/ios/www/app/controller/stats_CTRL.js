/* CONTROLLEUR : Stats
 * DESCRIPTION : Controlleur qui gère l'affichage des statistiques des valeurs récoltés par la station météo. */

app.controller('stats_CTRL',  function($scope, $rootScope) {
	// defines :
	$scope._root = $rootScope;
	$scope.currentTab = "jour";
	
	// methods :
	$scope.changeTab = function(tab){ $scope.currentTab = tab; };
	
	// traitements :
	$scope._root.page = "stats";
	
});