/* CONTROLLEUR : Sync
 * DESCRIPTION : Controlleur qui gère l'appel des datas au WebService quand il faut récupérer des données. */

app.controller('sync_CTRL', function($scope,$rootScope,$http,data) {
	// defines :
	$scope._root = $rootScope;
	$scope.requestWaitingFor = null;
	$scope.getRequestNumberWhile = 0;
	
	// methods :
	$scope.method_initSession = function(){
		// on ce connecte au webservice avec les paramètres de l'utilisateurs enregistré et on met à jour les données de l'utilisateur :
		if(String($scope._data.user.password).trim() == ""){ $scope.method_errorResultLogin(); return false; }
		
		if (navigator.onLine) {
			$http.post($scope._root.webservice+"user/connect", $scope._data.user).then(function (response) {
				if(response.status == "200") {
		            if(response.data.response.code == 1){ $scope.method_makeRequest(); }
		            else{ $scope.method_errorResultLogin(); return false; }
		        }
		        else{ $scope.method_errorResultLogin(); return false; }
			});
		}
		
		// Si pas d'accès à internet :
		else{ $scope._root.alert($scope._root.language.recupere("base.no-network")); }
	};
	$scope.method_errorResultLogin = function(){ 
		$scope._root.view("/user/login");
	};
	$scope.method_failResult = function(onError){ 
		if($scope._root.alert($scope._root.language.recupere("base.error"))){
			$scope._root.view("/user/account");
		}
	};
	$scope.method_makeRequest = function(){
		console.log("SYNC : Session init OK.");
		
		var data = {"request": "SELECT (SELECT moyenne FROM m_data_temp WHERE YEAR(NOW())= YEAR(date) && MONTH(NOW())= MONTH(date) && DAY(NOW())= DAY(date) && HOUR(NOW())= HOUR(date) && MINUTE(NOW())= MINUTE(date)) as 'temp', (SELECT moyenne FROM m_data_pre WHERE YEAR(NOW())= YEAR(date) && MONTH(NOW())= MONTH(date) && DAY(NOW())= DAY(date) && HOUR(NOW())= HOUR(date) && MINUTE(NOW())= MINUTE(date)) as 'pression', (SELECT moyenne FROM m_data_hum WHERE YEAR(NOW())= YEAR(date) && MONTH(NOW())= MONTH(date) && DAY(NOW())= DAY(date) && HOUR(NOW())= HOUR(date) && MINUTE(NOW())= MINUTE(date)) as 'humidite', (SELECT cumul FROM m_data_pluie WHERE YEAR(NOW())= YEAR(date) && MONTH(NOW())= MONTH(date) && DAY(NOW())= DAY(date) && HOUR(NOW())= HOUR(date) && MINUTE(NOW())= MINUTE(date)) as 'pluie', (SELECT max FROM m_data_venti WHERE YEAR(NOW())= YEAR(date) && MONTH(NOW())= MONTH(date) && DAY(NOW())= DAY(date) && HOUR(NOW())= HOUR(date) && MINUTE(NOW())= MINUTE(date)) as 'venti_max', (SELECT direction FROM m_data_venti WHERE YEAR(NOW())= YEAR(date) && MONTH(NOW())= MONTH(date) && DAY(NOW())= DAY(date) && HOUR(NOW())= HOUR(date) && MINUTE(NOW())= MINUTE(date)) as 'venti_direction', (SELECT moyenne FROM m_data_ventm WHERE substr(NOW(),1,15) = substr(date,1,15)) as 'ventm_moyenne', (SELECT direction FROM m_data_ventm WHERE substr(NOW(),1,15) = substr(date,1,15)) as 'ventm_direction';"};
		
		if (navigator.onLine) {
			$http.post($scope._root.webservice+"request/app/push", data).then(function (response) {
				if(response.status == "200") {
		            if(response.data.response.code == 1){ 
		            	// Ajout de la request au tableau :
		            	$scope.requestWaitingFor = response.data.response.data.request_id;
		
						// On récupére les requetes qui sont passé en push :
				    	$scope.method_getRequest(); 
		            }
		            else{ $scope.method_failResult(); return false; }
		        }
		        else{ $scope.method_failResult(); return false; }
			});
		}
		
		// Si pas d'accès à internet :
		else{ $scope._root.alert($scope._root.language.recupere("base.no-network")); }
	};
	$scope.method_getRequest = function(){
		console.log("SYNC : Push request OK.");
		
		$scope.getRequestNumberWhile++;
		
	    if (navigator.onLine) {
			$http.post($scope._root.webservice+"request/app/pull", {"id": $scope.requestWaitingFor}).then(function (response) {
				if(response.status == "200") {
		            if(response.data.response.code == 1){ 
		            	$scope._data.bdd.data_minutes = response.data.response.data.response;
		            	$scope._root.view("/home");
		            }
		            else{ 
		            	if($scope.getRequestNumberWhile<=5){ $scope.method_getRequest(); } 
		            	else{ $scope.method_failResult(); $scope.getRequestNumberWhile = 0; }
		            	return false; }
		        }
		        else{ $scope.method_failResult(); return false; }
			});
		}
	
		// Si pas d'accès à internet :
		else{ $scope._root.alert($scope._root.language.recupere("base.no-network")); pull = true; }
		
		console.log("SYNC : Pull request OK.");
	};
	$scope.method_init = function(){
		// on bloque le changement de page
		
		// on lance la session de récupération des données :
		$scope.method_initSession();
	};	
	
	// traitements :
	$scope._root.page = "sync";
	$scope.method_init();
});