/* CONTROLLEUR : Base
 * DESCRIPTION : Système d'informationde l'application, il s'agit du controlleur par défault qui gère l'ensermble de l'application. */

app.controller('base_CTRL', function($scope, $rootScope, $location, $interval, localStorageService, language, data) {
	// defines :
	$scope._root = $rootScope;
	$scope._data = data;
	
	// configure :
	$scope._root.alert = function(msg){
		try{ navigator.notification.alert(msg, function(){}, 'Information', 'OK'); }
		catch(e){ alert(msg); }
		
		return true;
	};
	
	// methodes :
	$scope.method_init = function(){
		if(typeof data.user != "undefined"){
			if(data.user != null){ $location.path("/sync"); }
			else{ $location.path("/user/login"); }
		}
		else{ navigator.app.exitApp(); }
	};
	$scope._root.view = function(view){ 									// change view
		// Specific case :
		var url = $location.url();
		if(view == "/user"){
			try{
				if($scope._data.bdd.user != null){ view = "/user/account"; }
				else{ view = "/user/login"; }
			}catch(e){
				 view = "/user/login";
			}
		}
		if(view == "/home" || view == "/stats"){
			try{ if($scope._data.bdd.data_minutes == null){ view = "/sync"; }
			}catch(e){ view = "/sync"; }
		}
		
		$location.path(view); };
	$scope._root.language = language;
	
	// traitements :
	$scope._root.webservice = "http://daweather.ovh/webservice/";			// on définit l'url du webservice
	$scope._root.page = null;												// on met la page à null.
	$scope.method_init();
	
	// persistance :
	$scope._data.restore();													// on restaure l'état des données de l'application
	this.sav = $interval(function() { $scope._data.automate(); }, 500);		// on sauvegarde l'état des données de l'application
});