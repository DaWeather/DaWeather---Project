/* CONTROLLEUR : Info
 * DESCRIPTION : Controlleur qui gère l'affichage de la partie à propos de l'application. */

app.controller('info_CTRL', function($scope, $rootScope) {
	// defines :
	$scope._root = $rootScope;
	
	// traitements :
	$scope._root.page = "info";
	
});