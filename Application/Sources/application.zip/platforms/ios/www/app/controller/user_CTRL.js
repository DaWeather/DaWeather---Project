/* CONTROLLEUR : User
 * DESCRIPTION : Controlleur qui gère la connexion de l'utilisateur et l'affichage de son profil. */

app.controller('user_CTRL', function($scope,$rootScope,$http,data) {
	// defines :
	$scope._root = $rootScope;
	$scope._data = data;
	
	// methodes :
	$scope.method_init = function(){
		// redirection d'accès de login à account si connecter : 
		try{
			if ($scope._data.bdd.user != null){  $scope._root.view("/user/account");}
		}catch(e){}
	};
	$scope.method_login = function(){
		// reception des valeurs entré :
		var user = {"email" : angular.element("#email").val(),
					"password" : angular.element("#password").val() };
		if(String(user.email).trim() == "" || String(user.password).trim() == ""){ return false; }
		
		// enregistrement des valeurs reçu :
		$scope._data.user = user;
		
		// si connecter à internet :
		if (navigator.onLine) {
			// TODO : Mettre le loader
			
			// on tente de ce connecter :
			$http.post($scope._root.webservice+"user/connect", user).then(function (response) {
				if(response.status == "200") {
		            if(response.data.response.code == 1){
		            	$scope._data.bdd.user = response.data.response.data;
		            	$scope._root.view("/home");
		            }else{ $scope._root.alert($scope._root.language.recupere("user.login.error_form")); }
		        }
		        else{
		        	$scope._root.alert($scope._root.language.recupere("base.error"));
		        } 
	        });
	        
			// TODO : Enlever le loader
		}
		
		// Si pas d'accès à internet :
		else{ $scope._root.alert($scope._root.language.recupere("base.no-network")); }
	};
	$scope.method_login_help = function(){
		$scope._root.alert($scope._root.language.recupere("user.login.help_message"));
	};
	$scope.method_register = function(){
		// reception des valeurs entrés :
		var user = {"email" : angular.element("#email").val(),
					"name" : angular.element("#name").val(),
					"password" : angular.element("#password").val() };
		if(String(user.name).trim() == "" || String(user.email).trim() == "" || String(user.password).trim() == ""){ 
			$scope._root.alert($scope._root.language.recupere("user.register.error_form_type")); 
			return false; 
		}
		
		// si connecter à internet :
		if (navigator.onLine) {
			// TODO : Mettre le loader
			
			// on tente de ce connecter :
			$http.post($scope._root.webservice+"user/register", user).then(function (response) {
				if(response.status == "200") {
		            if(response.data.response.code == 1){
						// enregistrement des valeurs reçu :
						$scope._data.user.email = user.email;
						$scope._data.user.password = user.password;
						
						// enregistrement ok :
						$scope._root.alert($scope._root.language.recupere("user.register.valid")); 
						
						// on redirige sur login
		            	$scope._root.view("/user/login");
		            }else{ $scope._root.alert($scope._root.language.recupere("user.register.error_form_format")); }
		        }
		        else{ $scope._root.alert($scope._root.language.recupere("base.error")); } 
	        });
	        
			// TODO : Enlever le loader
		}
		
		// Si pas d'accès à internet :
		else{ $scope._root.alert($scope._root.language.recupere("base.no-network")); }
	};
	$scope.method_disconnect = function(){
		// on ce déconnecte 
    	$scope._data.user.password = "";					// suppression du mot de passe
    	$scope._data.bdd.user = null;						// suppression des données de l'utilisateur
    	$scope._root.view("/user/login");					// retour à connexion
	};
	
	
	// traitements :
	$scope._root.page = "user";
	$scope.method_init();
	
});