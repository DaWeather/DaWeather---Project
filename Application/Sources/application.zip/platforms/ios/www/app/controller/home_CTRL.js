/* CONTROLLEUR : Home
 * DESCRIPTION : Controlleur qui gère l'affichage des données de la station météo le jour J et les autres jours. */

app.controller('home_CTRL', function($scope, $rootScope, data) {
	// defines :
	$scope._root = $rootScope;
	$scope._data = data;
	
	// methods :
	
	// traitements :
	$scope._root.page = "home";
});