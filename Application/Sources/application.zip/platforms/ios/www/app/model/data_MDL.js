app.service("data", function ($interval, localStorageService) {
	// defines
	this.user = {"email":"", "password":""};
	this.bdd = {"user": null,"data_minutes": null,"data_hours": null,"data_days": null};
	
	// methods :
	this.save = function() {
		localStorageService.set('user', this.user);
		localStorageService.set('bdd', this.bdd);
	};
	this.restore = function() {
		if(localStorageService.get('user') == null || localStorageService.get('bdd') == null){ this.save(); }
		
		if(typeof localStorageService.get('user') != "undefined") { this.user = localStorageService.get('user'); }
		if(typeof localStorageService.get('bdd') != "undefined") { this.bdd = localStorageService.get('bdd'); }
	};
	this.automate = function() {		
		if(localStorageService.get('user') != this.user || localStorageService.get('bdd') != this.bdd){ this.save(); }
	};
	
	// traitements :
});