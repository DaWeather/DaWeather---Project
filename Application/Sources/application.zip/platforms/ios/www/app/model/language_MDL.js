app.service("language", function (localStorageService) {
	// DECLARES :
	this.lang_default = 'en';   
	this.dictionnaire = {
		// FRENCH :
		fr : {
			base : {
				"error" : "Une erreur s'est produite.",
				"no-network" : "Pas d'accès à internet."
			},
			home : {
				"localisation" : "Gradignan",
				"date" : "Lundi 12 Mars",
				"hour" : "12h00",
				"title1" : "Aujourd\'hui",
				"title2" : "Hier",
				"temp" : "Température",
				"tempValue" : "20",
				"tempUnit" : "°C",
				"pression" : "Pression",
				"pressValue" : "1 020",
				"pressUnit" : "hPa",
				"humidity" : "Humidité",
				"humiValue" : "15",
				"humiUnit" : "%",
				"precipitation" : "Précipitations",
				"preciValue" : "0,5",
				"preciUnit" : "mL",
				"wind" : "Vents",
				"windValue" : "Nord/Est",
				"rafale" : "Rafale",
				"rafaleValue" : "130",
				"rafaleUnit" : "km / h"
			},
			user : {
				login : {
					"title" : "Se connecter",
					"login" : "E-mail",
					"password" : "Mot de passe",
					"btn-login" : "SE CONNECTER",
					"btn-signin" : "S\'ENREGISTRER",
					"help" : "Besoin d\'aide ?",
					"help_message" : "Problèmes de mot de passe ou de connexion, assurez vous d'avoir correctement taper votre mot de passe ou contacter le webmaster.",
					"error_form" : "Addresse mail ou mot de passe incorrecte."
				},
				account : {
					"title" : "Mon Compte",
					"station" : "Station",
					"localisation" : "Localisation",
					"altitude" : "Altitude",
					"btn-logout" : "SE DECONNECTER",
					"error_disconnect" : "La déconnexion à échouer."
				},
				register : {
					"title" : "S\'enregistrer",
					"name" : "Nom & Prénom",
					"mail" : "E-mail",
					"password" : "Mot de passe",
					"btn-login" : "SE CONNECTER",
					"btn-signin" : "S\'ENREGISTRER",
					"valid" : "Enregistrement effectué avec succès.",
					"error_form_type" : "Merci de bien vouloir saisir tous les champs demander.",
					"error_form_format" : "Merci de bien vouloir saisir une addresse mail valide et unique, un nom unique et un mot de passe d'au moins 8 caractères."
				},
			},
			sync : {
				"title" : "Synchronisation",
				"text" : "Synchronisation en cours"
			},
			stats : {
				"title" : "Historique",
				"jour" : "Jour",
				"mois" : "Mois",
				"annee" : "Année"
			},
			info : {
				"title" : "A Propos",
				"text1" : "Cette application a été développé pendant un ",
				"colored1" : "projet tutoré",
				"text2" : " de la licence professionnelle",
				"colored2" : " DAWIN ",
				"text3" : "par",
				"text4" : "Avec le soutien de l\'",
				"underline1" : "IUT INFO de Bordeaux",
				"copyright" : "© Copyright DaWeather - Tous droits réservés"
			},
		},
		// ENGLISH :
		en : {
			base : {
				"error" : "An error occurred.",
				"no-network" : "No internet access."
			},
			home : {
				"localisation" : "Gradignan",
				"date" : "Monday, 12th of March",
				"hour" : "12am",
				"title1" : "Today",
				"title2" : "Yesterday",
				"temp" : "Temperature",
				"tempValue" : "68",
				"tempUnit" : "°F",
				"pression" : "Pressure",
				"pressValue" : "1 020",
				"pressUnit" : "hPa",
				"humidity" : "Humidity",
				"humiValue" : "15",
				"humiUnit" : "%",
				"precipitation" : "Precipitations",
				"preciValue" : "0,5",
				"preciUnit" : "mL",
				"wind" : "Wind",
				"windValue" : "North/Est",
				"rafale" : "Gust",
				"rafaleValue" : "80.7",
				"rafaleUnit" : "mph"
			},
			user : {
				login : {
					"title" : "Log In",
					"login" : "E-mail",
					"password" : "Password",
					"btn-login" : "LOG IN",
					"btn-signin" : "SIGN IN",
					"help" : "Need help ?",
					"help_message" : "Password or connection problems, make sure you correctly type your password or contact the webmaster.",
					"error_form" : "Mail address or password incorrect."
				},
				account : {
					"title" : "My Account",
					"station" : "Station",
					"localisation" : "Localisation",
					"altitude" : "Altitude",
					"btn-logout" : "LOG OUT",
					"error_disconnect" : "Disconnection failed."
				},
				register : {
					"title" : "SIGN IN",
					"mail" : "Email",
					"name" : "First & last name",
					"password" : "Password",
					"btn-login" : "LOG IN",
					"btn-signin" : "SIGN IN",
					"valid": "Registration completed.",
					"error_form_type": "Please complete all asked fields.",
					"error_form_format": "Please enter a valid and unique email address, a unique name and a password at least 8 characters."
				},
			},
			sync : {
				"title" : "Synchronization",
				"text" : "Synchronization in progress"
			},
			stats : {
				"title" : "Statistic",
				"jour" : "Day",
				"mois" : "Month",
				"annee" : "Year"
			},
			info : {
				"title" : "About",
				"text1" : "This application have been developed during a ",
				"colored1" : "tutored project",
				"text2" : " of professional degree after a 3 year course in ",
				"colored2" : " DAWIN ",
				"text3" : "by",
				"text4" : "With support of ",
				"underline1" : "Bordeaux IT Department",
				"copyright" : "© Copyright DaWeather - All Rights Reserved"
			},	
		}		
	};

	
	// METHODES :
	// detect lang of DEVICE :
	this.lang = function checkLanguage() {
		var retour = this.lang_default;
		try{
			if (navigator.globalization !== null && navigator.globalization !== undefined) {
				navigator.globalization.getPreferredLanguage(
					function (language) { retour = language; },
					function (error) { retour = error; }
				);
			} else {
				if(window.navigator.language !== null && window.navigator.language !== undefined) {
					retour = window.navigator.language;
				}
				else {
					retour = this.lang_default;
				}
			};
		}catch(e){ retour = this.lang_default; }
		
		return String(retour).substring(0,2);
    };
    // get the correct libelle in lang :
	this.recupere = function(libelle, type, lang){
		var retour = "";
		
		// get lang if not precise :
		if(typeof lang == "undefined"){ lang = this.lang(); }
		
		// find :
		libelle = libelle.split(".");
		var object = this.dictionnaire[lang];
		for(i=0; i<=(libelle.length-1); i++){
			object = object[libelle[i]];
		}
		retour = object;

		// check return :
		if(typeof retour == "undefined"){
			retour="";
		}

		// clean by filter :
		if(typeof type != "undefined" && type != null){
			switch (type){
				case "uppercase":
					retour = String(retour).toUpperCase();
					break;

				case "lowercase":
					retour = String(retour).toLowerCase();
					break;

				case "firstUppercase":
					retour = String(retour);
					retour = String(retour.charAt(0)).toUpperCase() + retour.substring(1);
					break;
			}
		}
		
		return retour;
	};
});