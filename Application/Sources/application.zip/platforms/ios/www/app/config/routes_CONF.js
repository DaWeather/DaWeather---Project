// ROUTES Config :

app.config(['$routeProvider',function ($routeProvider) {
    $routeProvider.when("/", {
		templateUrl: "app/view/sync/sync.html",
		controller: "sync_CTRL"
    });

	$routeProvider.when("/user/login", {
		templateUrl: "app/view/user/login.html",
		controller: "user_CTRL"
	});

	$routeProvider.when("/user/logout", {
		templateUrl: "app/view/user/logout.html",
		controller: "user_CTRL"
	});
	
    $routeProvider.when("/user/register", {
        templateUrl: "app/view/user/register.html",
        controller: "user_CTRL"
    });
	$routeProvider.when("/user/account", {
		templateUrl: "app/view/user/account.html",
		controller: "user_CTRL"
	});

    $routeProvider.when("/home", {
        templateUrl: "app/view/home/home.html",
        controller: "home_CTRL"
    }); 

    $routeProvider.when("/stats", {
        templateUrl: "app/view/stats/stats.html",
        controller: "stats_CTRL"
    });

    $routeProvider.when("/sync", {
        templateUrl: "app/view/sync/sync.html",
        controller: "sync_CTRL"
    });

    $routeProvider.when("/info", {
        templateUrl: "app/view/info/info.html",
        controller: "info_CTRL"
    });
}]);