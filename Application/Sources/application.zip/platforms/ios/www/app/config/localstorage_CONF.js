// LOCALSTORAGE Config :

app.config(['localStorageServiceProvider', function (localStorageServiceProvider) {
    // LocalStorage in browser :
    localStorageServiceProvider.setPrefix('daweather_');
}]);