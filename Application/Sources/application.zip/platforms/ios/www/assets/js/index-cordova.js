/* CORDOVA */

var cordova = {
	// initilisation :
    initialize: function() {
        this.bindEvents();
    },
    // evenement :
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // chargement OK :
    onDeviceReady: function() {
    	console.log("Fonctions de l'aplication prête.");
    }
};

cordova.initialize();