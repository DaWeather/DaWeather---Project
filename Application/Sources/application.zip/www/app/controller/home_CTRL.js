/* CONTROLLEUR : Home
 * DESCRIPTION : Controlleur qui gère l'affichage des données de la station météo le jour J et les autres jours. */

app.controller('home_CTRL', function($scope, $rootScope, data) {
	// defines :
	$scope._root = $rootScope;
	$scope._data = data;
	
	$scope._data.bdd.data_minutes = $scope._data.bdd.data_minutes[0];
	
	angular.forEach($scope._data.bdd.data_minutes, function(value, key) {
	    $scope._data.bdd.data_minutes[key] = parseFloat(value).toFixed(2);
	});
	// methods :
	
	// traitements :
	$scope._root.page = "home";
});